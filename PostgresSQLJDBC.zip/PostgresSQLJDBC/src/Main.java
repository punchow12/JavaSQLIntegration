
import java.sql.*;


/*** Ahmed Babar 101154651
 * The Main class is for connecting to a Postegres Database using JDBC Driver, postegresSQL.jar is needed.
 */
public class Main {
    // Log in information for PG4admin on my computer
    private final String url = "jdbc:postgresql://localhost/assignment4";
    private final String user = "postgres";
    private final String password = "password123";

    private Connection connection;
    public Main(){
        connection = this.connect();

    }

    /***
     * Connect to Postgres Server
     * @return Connection object
     */
    public Connection connect() {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        System.out.printf("Hello and welcome!");

        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the PostgreSQL server successfully.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    /***
     *  Retrieves and displays all records from the students table.
     */
    public void getAllStudents(){
        //HashMap hm = new HashMap<>();
        String SQL = "SELECT * FROM public.students ORDER BY student_id ASC";
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(SQL);
            System.out.println("student_id|first_name|last_name|email|enrollment_date");
            while (resultSet.next()){
                //hm.put(resultSet.getString("first_name"),resultSet.getString("first_name"),resultSet.getString("first_name"),resultSet.getString("first_name"))
                System.out.println(resultSet.getString("student_id")+
                        "|"+resultSet.getString("first_name")+
                        "|"+resultSet.getString("last_name")+
                        "|"+resultSet.getString("email")+
                        "|"+resultSet.getString("enrollment_date"));
            }
            //int rows = statement.executeUpdate(SQL);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /***
     * Inserts a new student record into the students table.
     * @param first_name column1
     * @param last_name column2
     * @param email column3
     * @param enrollment_date column4
     */
    public void addStudent(String first_name, String last_name, String email, String enrollment_date){
        String SQL = "INSERT INTO students (first_name, last_name, email, enrollment_date) VALUES" +
                "('"+first_name+"', '"+last_name+"', '"+email+"', '"+enrollment_date+"');";
        // "('Jo', 'ey', 'jo.oe@example.com', '2026-09-01');";
        //" ('" + first_name + "', '" + last_name + "', '" + email + "', '" + enrollment_date + "');"
        try {
            Statement statement = connection.createStatement();
            int rows = statement.executeUpdate(SQL);
            if (rows > 0) {
                System.out.println("A new Student has been added to the Table: students");
            }
        } catch (SQLException e) {
            System.out.print("Connection failed ");
            e.printStackTrace();
        }
    }

    /***
     * Updates the email address for a student with the specified student_id.
     * @param student_id Primary Key
     * @param new_email New Email to set
     */
    public void updateStudentEmail(String student_id, String new_email){

        String SQL = "UPDATE students SET email = '"+new_email+"' WHERE student_id = '"+student_id+"';";
        try {
            Statement statement = connection.createStatement();
            int rows = statement.executeUpdate(SQL);
            if (rows > 0 ){
                System.out.println("successfully updated email.");
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    /***
     * Deletes the record of the student with the specified student_id.
     * @param student_id Primary key student to delete
     */
    public void deleteStudent(String student_id){
        String SQL = "DELETE FROM students WHERE student_id = '"+student_id+"';";
        try {
            Statement statement = connection.createStatement();
            int rows = statement.executeUpdate(SQL);
            if (rows > 0 ){
                System.out.println("successfully deleted student.");
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Main sqlTest = new Main();

        //sqlTest.addStudent("diver","Dio","dio.holydiv@example.com","2013-09-01");
        //sqlTest.getAllStudents();
        //sqlTest.updateStudentEmail("13","changed@email.com");
        sqlTest.deleteStudent("13");
        //sqlTest.deleteStudent("3");
        //sqlTest.deleteStudent("8");
        //sqlTest.deleteStudent("9");
        //connection.close();
    }
}